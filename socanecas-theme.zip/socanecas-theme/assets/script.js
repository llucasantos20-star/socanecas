// Snowflakes
const snowCount = 50;
for(let i=0; i<snowCount; i++){
  let snow = document.createElement('div');
  snow.className = 'snowflake';
  snow.style.left = Math.random()*100 + 'vw';
  snow.style.fontSize = (Math.random()*10 + 10) + 'px';
  snow.style.animationDuration = (Math.random()*10 + 5) + 's';
  snow.style.opacity = Math.random();
  snow.innerHTML = '❄';
  document.body.appendChild(snow);
}

// Hamburger menu
const hamburger = document.querySelector('.hamburger');
const navUl = document.querySelector('header nav ul');
hamburger.addEventListener('click', ()=>{ navUl.classList.toggle('show'); });

// Scroll animation
const sections = document.querySelectorAll('.section');
const observer = new IntersectionObserver((entries)=>{
  entries.forEach(entry=>{
    if(entry.isIntersecting){ entry.target.classList.add('visible'); }
  });
}, {threshold:0.2});
sections.forEach(sec=>observer.observe(sec));